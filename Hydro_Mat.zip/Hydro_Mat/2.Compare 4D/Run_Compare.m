clc; close all; clear all;

% Compare_4D_MLE: Allows to Compare 4 Probability Distributions using Maximum Likelihood Estimation (MLE) 
% By:  T. Benkaci & N.Dechemi -2019-   
% The four Probability Distributions are : 
% 1- Log Normal Distribution 
% 2- Gumbel Distribution      
% 3- General Extreme Values (GEV)  
% 4- GAMMA Distribution     
%  The Comparison is based on Root Mean Squared Error (RMSE).
%  Displays The different quantiles for the best Probability Fit. 

global P y m s n f 
%% Data Loaded
% Load Main File: with two columns
% Read Observed Data (Annual Rainfall(mm)), using Excel File.
%PP = xlsread('File_Data.xlsx');
PP = xlsread('Compare_Data.xlsx'); 
% You can use: Text file instead: PP = load('File_Data.txt').
D=PP(1:end,1:1); % The first Column is the Date (Years)
P=PP(1:end,2:2); % The Second Column is the Observed Data: Annual Precipitations in mm.

%% Statistical of Data used
% Caracteristics of Data, will be used in the Main program
% Caracteristiques Statistiques, seront utilisees dans le programme principal
n=length(P);
m=mean(P); s=std(P);  % Mean and Standard Deviation
y=sort(P);
Cs=skewness(P); % Skewness of Data-  Coefficient d'Asymetrie


%% Plot Position Formula : We use 2 Formula:
% Probability Plot Position Formula---Frequence Empirique--Methode de HAZEN
j=1;% Plot Position: 1=Hazen method  - use 2= Weibull Formula Instead
    for i=1:n 
    if j==1
    f(i)=(i-0.5)/(n);
    else j==2
%Probability Plot Position Formula---Frequence Empirique--Methode de WEIBULL
    f(i)=i/(n+1);
    end
    end

%% Main File 
% The Main File Calculations (Protected File Pcode)
Main_Func