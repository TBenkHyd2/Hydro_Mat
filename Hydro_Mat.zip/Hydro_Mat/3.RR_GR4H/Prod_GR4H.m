function [V,PR] = Prod_GR4H(x,V,NH,PR,P,E,MaxPar);
d=21/4;
if P <= E, 
    PR = 0;
    WS=(E-P)/x(1);
     if(WS>13);WS=13;end;
    
ES=V(1)*(2-(V(1)/x(1)))*tanh(WS)/(1+(1-(V(1)/x(1)))*tanh(WS)); 
V(1)=V(1)-ES;
elseif P > E, 
  ES=0;   
 WS=(P-E)/x(1);
 if(WS>13);WS=13;end;

PS=(x(1)*(1-(V(1)/x(1))^2)*tanh(WS)/(1+(V(1)/x(1))*tanh(WS)));
PR=(P-E)-PS;
 V(1)=V(1)+PS;
end;

if V(1) <= 0.001, V(1)=0;end

% Percolation
	PERC=V(1)*(1.-(1.+(V(1)/(d.*x(1)))^4.)^(-0.25));
      V(1)=V(1)-PERC;   

PR=PR+PERC;



         