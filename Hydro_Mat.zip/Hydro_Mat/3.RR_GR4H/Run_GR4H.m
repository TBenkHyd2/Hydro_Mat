% MODELING HOURLY RAINFALL-RUNOFF PROCESS USING "GR4H" MODEL (BY TARIK BENKACI and N. DECHEMI (1998-2018)) 
% COMPILATION DU MODELE PLUIE-DEBIT HORAIRE "GR4H"  
% OPTIMISATION METHOD : Modified SCE-UA--SPI Method  (Duan et al.(93)& Chu et al.2011 
Optim_GR4H
% thus the code Run optimisation Process to found best parameters of Conceptual GR4H model, with 4 parameters
%After optimisation the model displays and save the results in GR4H.xls results and RESULTS Text file
% And the model can simulate new runoff values with GR4H_SIM