% RAINFALL-RUNOFF MODEL MODEL (GR4J WITH 4 PARAMETERS) BY TARIK BENKACI & N. DECHEMI 
% Optimisation of GR4J is modified SCE-UA (SPI) Optimisation method (Duan et al., 1992, 1993) 
Optim_GR4J
% Duan,  Q., Sorooshian, S. and Gupta, V.K., 1993. & %Wei Chu ?, Xiaogang Gao, Soroosh Sorooshian A new evolutionary search strategy for global 
%optimization of highdimensional problems Information Sciences - 2011
%References of GR4J
%Perrin, C., 2000. Vers une am�lioration d�un mod�le global pluie-d�bit au travers d�une approche comparative. Thesis (PhD). Grenoble, France, 530 p.
%Perrin, C., Michel, C. and Andr�assian, V., 2003. Improvement of a parsimonious model for streamflow simulation. Journal of Hydrology, 279, 275-289. 

%data=load('File_Data.txt'); % File of Data, do not change Name of this File, only copy and paste your Data
%P = data(:,1);  % First Vector : Rainfall (in mm)
%E = data(:,2);  % Second Vector : Evapotranspiration (in mm)
%Qobs=data(:,3); % Third Vector of Data  (in m3/s)
%param=load('parameters.txt'); % Paremters of Calibration
%Sup=param(1);  %Area of Basin in km2
% Bounds=load('Initial_Param.txt');% The Initial Parameters loaded from text File
% bl=Bounds(1:4)'  % Lower Bounds of Paramters
% bu=Bounds(5:8)'  % Upper Bounds of Paramters

% thus the code Run optimisation Process to found best parameters of Conceptual GR4j model, with 4 parameters
%Finally after optimisation the model can simulate new runoff values with GR4J. 
                                                          %Dr T.B


