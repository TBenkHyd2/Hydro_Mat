function [Thes_BF,Q0] = Base_Flow_T(Qobs)
% Calculate Threshold that will be considered as Base Flow (Tarik Benkaci)
%Inputs:
% Qobs       - time series of Observed Flow       [m3/s]

% Outputs:
% Q0        - Mean of Observed Flow (m3/s)
% Thes_BF   - Thes_BF : Threshold of Base Flow < I assume that Q<Thes_BF is base Flow        


% calculate THreshold of Base Flow for Observed Flow
    Q0=mean(Qobs);
    if Q0<= 8.
Thes_BF= 1 ;
    elseif Q0<100 & Q0>8 
Thes_BF= mean(Qobs)/8;
      elseif Q0>=100
Thes_BF= mean(Qobs)/10;
    end
end