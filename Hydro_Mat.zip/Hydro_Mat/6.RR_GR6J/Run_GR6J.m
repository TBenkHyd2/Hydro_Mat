clc; clear all; close all;
%  RAINFALL-RUNOFF MODEL (GR6J WITH 6 PARAMETERS) BY TARIK BENKACI &  N. DECHEMI 
% Optimisation Method: 1- SCE-UA   2: deterministic Method: Interior Point  Algorithm
% After many epoch of optimisation Model displays the best parameters of GR6J model.

disp('    %%%%%%%%%%%%   GR6J RAINFALL-RUNOFF  MODEL  %%%%%%%%%%%%%%%%              ')
disp('     %%  PARAMETERS ESTIMATION --  CHOOSE A METHOD   :     %%    ')
disp('     ***   1- STOCHASTIC OPTIMISATION :   SCE-UA METHOD  ***             ')
disp('     ***   2- DETERMINISTIC OPTIMISATION  INTERIOR POINT ALGORITHM ***   ')

j=input('   *** CHOIX DE LA METHODE D''OPTIMISATION - CHOOSE A METHOD OF OPTIMISATION :     '),
if j==1
    disp('GR6J SCEUA OPTIMISATION')
    SCEUA_GR6J
elseif j==2
        disp('DETERMINISTIC OPTIMISATION ')
    DETER_GR6J
end
% Thus the code Run optimisation Process to Search best parameters of GR6j model
% After optimisation the model displays and save the results in RES_GR6J.xls & RESULTS Text file
% Good Modelling !
  % Dr T.B


