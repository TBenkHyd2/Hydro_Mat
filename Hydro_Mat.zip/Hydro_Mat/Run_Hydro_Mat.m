clc; clear all; close all;
%           disp(             '             &&-----------------------------------------------------------------------------------&&  ')
%          disp(             '             &&--------  HYDRO_MAT 1.0:  Hydrological Software using Matlab               --------&&  ')
%         disp(             '             &&--------  HYDRO_MAT 1.0:  Logiciel de Simulations Hydrologiques S/ Matlab  --------&&  ')
%          disp(             '             &&--------        BY TARIK BENKACI & N. DECHEMI 2022                         --------&&  ')
%          disp(             '             &&-----------------------------------------------------------------------------------&&  ')
%          disp(             '             &&-----------------------------------------------------------------------------------&&  ')
     %  for any suggestions, Bugs, comments contact  Benkaci Tarik benktar@gmail.com
Main_HM